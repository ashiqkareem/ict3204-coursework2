import os
import json
from cleaner import Cleaner

TSHARK_FPATH = os.path.join("raw_logs", "tshark_raw_Gp15_all.json")
FILEBEAT_FPATH = os.path.join("raw_logs", "filebeat_raw_Gp15_all.json")

FINAL_PATH = "clean_logs"


def export_to_json(rawdata, technique_id, data_src, stud_name):
    """
    Export Raw Data to json file
    """
    with open(
        os.path.join(
            FINAL_PATH, f"{technique_id}_{data_src}_clean_Gp15_{stud_name}.json"
        ),
        "w",
    ) as out_file:
        for line in rawdata:
            out_file.write(json.dumps(line))
            out_file.write("\n")


def main():
    """
    Main Function
    """
    # Processing of raw data
    filebeat = Cleaner(file_name=FILEBEAT_FPATH)
    tshark = Cleaner(file_name=TSHARK_FPATH)

    ## Chin Clement
    ## Initital Access (TA0001) - External Remote Services (T1133)
    export_to_json(
        rawdata=filebeat.external_remote_service(),
        technique_id="T1133",
        data_src="filebeat",
        stud_name="ChinClement",
    )

    ## Daniel Tan ZhongHao
    ## Discovery (TA0007) - Network Share Discovery (T1135)
    export_to_json(
        rawdata=tshark.network_share_discovery(),
        technique_id="T1135",
        data_src="tshark",
        stud_name="DanielTanZhongHao",
    )

    ## Gerald Peh Wei Xiang
    ## Collection (TA0009) - Data from Network Shared Drive (T1039)
    export_to_json(
        rawdata=filebeat.data_from_samba(),
        technique_id="T1039",
        data_src="filebeat",
        stud_name="GeraldPehWeiXiang",
    )

    ## Ho Xiuqi
    ## Lateral Movement (TA0008) - Remote Services: SSH (T1021.004)
    export_to_json(
        rawdata=filebeat.remote_system_discovery(),
        technique_id="T1021.004",
        data_src="filebeat",
        stud_name="HoXiuQi",
    )

    ## Lim Zhao Xiang
    ## Privilege Escalation (TA0004) - Abuse Elevation Control Mechanism: Sudo and Sudo Caching (T1548.003)
    export_to_json(
        rawdata=filebeat.abuse_elevation_control(),
        technique_id="T1548.003",
        data_src="filebeat",
        stud_name="LimZhaoXiang",
    )

    ## Tan Zhao Yea
    ## Collection (TA0009) - Data Staged: Remote Data Staging (T1074.002)
    export_to_json(
        rawdata=filebeat.remote_data_staging(),
        technique_id="T1074.002",
        data_src="filebeat",
        stud_name="TanZhaoYea",
    )


if __name__ == "__main__":
    main()
